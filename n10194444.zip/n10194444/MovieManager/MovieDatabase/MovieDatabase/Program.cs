﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieDatabase
{

    //BTreeNode Class
    public class BTreeNode
    {
        private IComparable item; // value
        private BTreeNode lchild; // reference to its left child 
        private BTreeNode rchild; // reference to its right child

        public BTreeNode(IComparable item)
        {
            this.item = item;
            lchild = null;
            rchild = null;
        }

        public IComparable Item
        {
            get { return item; }
            set { item = value; }
        }

        public BTreeNode LChild
        {
            get { return lchild; }
            set { lchild = value; }
        }

        public BTreeNode RChild
        {
            get { return rchild; }
            set { rchild = value; }
        }
    }

    // invariants: every node’s left subtree contains values less than or equal to 
    // the node’s value, and every node’s right subtree contains values 
    // greater than or equal to the node’s value
    public class BSTree : IBSTree
    {
        private BTreeNode root;

        public BSTree()
        {
            root = null;
        }

        public bool IsEmpty()
        {
            return root == null;
        }

        public bool Search(IComparable item)
        {
            return Search(item, root);
        }

        private bool Search(IComparable item, BTreeNode r)
        {
            if (r != null)
            {
                if (item.CompareTo(r.Item) == 0)
                    return true;
                else
                    if (item.CompareTo(r.Item) < 0)
                    return Search(item, r.LChild);
                else
                    return Search(item, r.RChild);
            }
            else
                return false;
        }

        public void Insert(IComparable item)
        {
            if (root == null)
                root = new BTreeNode(item);
            else
                Insert(item, root);
        }

        // pre: ptr != null
        // post: item is inserted to the binary search tree rooted at ptr
        private void Insert(IComparable item, BTreeNode ptr)
        {
            if (item.CompareTo(ptr.Item) < 0)
            {
                if (ptr.LChild == null)
                    ptr.LChild = new BTreeNode(item);
                else
                    Insert(item, ptr.LChild);
            }
            else
            {
                if (ptr.RChild == null)
                    ptr.RChild = new BTreeNode(item);
                else
                    Insert(item, ptr.RChild);
            }
        }

        // there are three cases to consider:
        // 1. the node to be deleted is a leaf
        // 2. the node to be deleted has only one child 
        // 3. the node to be deleted has both left and right children
        public void Delete(IComparable item)
        {
            // search for item and its parent
            BTreeNode ptr = root; // search reference
            BTreeNode parent = null; // parent of ptr
            while ((ptr != null) && (item.CompareTo(ptr.Item) != 0))
            {
                parent = ptr;
                if (item.CompareTo(ptr.Item) < 0) // move to the left child of ptr
                    ptr = ptr.LChild;
                else
                    ptr = ptr.RChild;
            }

            if (ptr != null) // if the search was successful
            {
                // case 3: item has two children
                if ((ptr.LChild != null) && (ptr.RChild != null))
                {
                    // find the right-most node in left subtree of ptr
                    if (ptr.LChild.RChild == null) // a special case: the right subtree of ptr.LChild is empty
                    {
                        ptr.Item = ptr.LChild.Item;
                        ptr.LChild = ptr.LChild.LChild;
                    }
                    else
                    {
                        BTreeNode p = ptr.LChild;
                        BTreeNode pp = ptr; // parent of p
                        while (p.RChild != null)
                        {
                            pp = p;
                            p = p.RChild;
                        }
                        // copy the item at p to ptr
                        ptr.Item = p.Item;
                        pp.RChild = p.LChild;
                    }
                }
                else // cases 1 & 2: item has no or only one child
                {
                    BTreeNode c;
                    if (ptr.LChild != null)
                        c = ptr.LChild;
                    else
                        c = ptr.RChild;

                    // remove node ptr
                    if (ptr == root) //need to change root
                        root = c;
                    else
                    {
                        if (ptr == parent.LChild)
                            parent.LChild = c;
                        else
                            parent.RChild = c;
                    }
                }

            }
        }
        public void PreOrderTraverse()
        {
            Console.Write("PreOrder: ");
            PreOrderTraverse(root);
            Console.WriteLine();
        }
        private void PreOrderTraverse(BTreeNode root)
        {
            if (root != null)
            {
                Console.Write(root.Item);
                PreOrderTraverse(root.LChild);
                PreOrderTraverse(root.RChild);
            }
        }

        public void InOrderTraverse()
        {
            Console.Write("InOrder: ");
            InOrderTraverse(root);
            Console.WriteLine();
        }

        private void InOrderTraverse(BTreeNode root)
        {
            if (root != null)
            {
                InOrderTraverse(root.LChild);
                Console.Write(root.Item);
                InOrderTraverse(root.RChild);
            }
        }

        public void PostOrderTraverse()
        {
            Console.Write("PostOrder: ");
            PostOrderTraverse(root);
            Console.WriteLine();
        }

        private void PostOrderTraverse(BTreeNode root)
        {
            if (root != null)
            {
                PostOrderTraverse(root.LChild);
                PostOrderTraverse(root.RChild);
                Console.Write(root.Item);
            }
        }

        public void Clear()
        {
            root = null;
        }
    }

    // invariants: every node’s left subtree contains values less than or equal to 
    // the node’s value, and every node’s right subtree contains values 
    // greater than or equal to the node’s value
    public interface IBSTree
    {
        // pre: true
        // post: return true if the binary tree is empty; otherwise, return false.
        bool IsEmpty();

        // pre: true
        // post: item is added to the binary search tree
        void Insert(IComparable item);

        // pre: true
        // post: an occurrence of item is removed from the binary search tree 
        //		 if item is in the binary search tree
        void Delete(IComparable item);

        // pre: true
        // post: return true if item is in the binary search true;
        //	     otherwise, return false.
        bool Search(IComparable item);

        // pre: true
        // post: all the nodes in the binary tree are visited once and only once in pre-order
        void PreOrderTraverse();

        // pre: true
        // post: all the nodes in the binary tree are visited once and only once in in-order
        void InOrderTraverse();

        // pre: true
        // post: all the nodes in the binary tree are visited once and only once in post-order
        void PostOrderTraverse();

        // pre: true
        // post: all the nodes in the binary tree are removed and the binary tree becomes empty
        void Clear();

    }

    //Simple class to represent tree nodes
    public class BSTNode
    {

        char item;         //data item
        BSTNode lChild; //reference to left child (less than this node)
        BSTNode rChild; //reference to right child (greater than this node)

        //Constructor
        public BSTNode(char ch)
        {
            item = ch;
        }

        //Properties
        public char Item
        {
            get { return item; }
            set { item = value; }
        }

        public BSTNode Left
        {
            get { return lChild; }
            set { lChild = value; }
        }

        public BSTNode Right
        {
            get { return rChild; }
            set { rChild = value; }
        }
    }

    //----------------------------------------------------------------------------------
    //Ignore Above for now
    //----------------------------------------------------------------------------------
    
    public class Movie
    {
        //Vars
        public String title;
        private string starring;
        private string director;
        private string duration; // was int
        private int genre;
        private int classificaiton;
        private string release_date; //was int
        Movie default_movie;

        //Use to be incrremeanted (++/ 1+) everytime movie is borrwed or is avaiable 
        private int copies_available;
        private int times_borrowed;

        //Movie Arrays
        //Arrays for the classifications and genres
        public static String[] Classisficiations = { "General (G)", "Parental Guidance (PG)", "Mature (M15+)", "Mature Accompanied (MA15+)" };
        public static String[] Genres = { "Drama", "Adventure", "Family", "Action", "Sci-fi", "Comedy", "Animated", "Thirller", "Other" };
        
        //Are Numbers due to Having to pick from the main menu

        //Object Array to store the Movie in (Movie Database)
        //Movie Class MUST USE BINARY TREE SEARCH
        Movie[] MovieCollection;

        Movie[] MemberMovieCollection;

        //Movie Object Properties 
        public string Movie_Title { get => title; set => title = value; }
        public string Movie_Starring { get => starring; set => starring = value; }
        public string Movie_Director { get => director; set => director = value; }
        public string Movie_Duration { get => duration; set => duration = value; }

        public int Movie_Genre { get => genre; set => genre = value; }                 //Doesn't set FROM GENRE STRING ARRAY right
        public int Movie_Classificaiton { get => classificaiton; set => classificaiton = value; }   ///Doesn't set FROM Classificaiton STRING ARRAY right
        public string Movie_Release_Date { get => release_date; set => release_date = value; }
        public int Movie_Copy_Num { get => copies_available; set => copies_available = value; }
        public int Movie_Times_Borrowed { get => times_borrowed; set => times_borrowed = value; }

        //Creating Object
        public Movie(string movie_title, string movie_starring, string movie_director, string movie_duration, int movie_genre, int movie_classifiation, string movie_release_date, int intial_copies)
        {
            this.title = movie_title;
            this.starring = movie_starring;
            this.director = movie_director;
            this.duration = movie_duration;
            this.genre = movie_genre;
            this.classificaiton = movie_classifiation;
            this.release_date = movie_release_date;
            this.copies_available = intial_copies;


            copies_available = intial_copies;
            times_borrowed = 0;

           MemberMovieCollection = new Movie[10];
        }

        //Assigning Movie Class to a new Movie Object 
        public Movie()
        {
            default_movie = new Movie ("TestMovie", "", "", "", 0, 0, "", 0);

            int Moviecount;
        }

        public void Borrow()
        {
            times_borrowed++;
        }

    }

    public class MovieCollection
    {

        public Movie[] MovieArray;

        int NumOfMovies;

        public MovieCollection()
        {
            //Constructing a movie
            Movie TestMovie = new Movie();

            MovieArray = new Movie[] { TestMovie, TestMovie, TestMovie, TestMovie, TestMovie, TestMovie, TestMovie, TestMovie, TestMovie, TestMovie };

            int NumOfMovies = 0;
        }

        public bool AddMovie(Movie movieitem)
        {
            //Max of Unqiue Movie Objects (10 Movies)
            if (NumOfMovies < 10)
            {
                MovieArray[NumOfMovies++] = movieitem;

                return true; //Movie was added
            }  
            return false; //Movie can't be added
        }

        public bool RemoveMovie(Movie movieitem)
        {
            MovieArray[NumOfMovies--] = movieitem;

            return true; //Movie was Removed
        }
    }


    public class Member
    {
        private String given_name;
        private String surname;
        private string address;
        private int phone_num;
        private int password;
        Member default_member;

        public int NumOfUsers;

        Movie[] MemberMovieCollection;

        int Moviecount;

        //Properties
        public string Given_name { get => given_name; set => given_name = value; }
        public string Surname { get => surname; set => surname = value; }
        public int Password { get => password; set => password = value; }

        public int PhoneNum { get => password; set => phone_num = value; }


        //Creating object
        public Member(String given_name, String surname, string address, int phone_num, int password)
        {
            this.given_name = given_name;
            this.surname = surname;
            this.address = address;
            this.phone_num = phone_num;
            this.password = password;

            //Starts up with 10 members in array on each object (MEMBER)
            MemberMovieCollection = new Movie[10];
        }

        public Member()
        {
            default_member = new Member("test", "", "", 0, 0);
        }

        public string GetUsername()
        {
            return surname + given_name;
        }

        //Assgining MemberMovieMemember a MovieCount and Increaments to borrowed_movie
        //Never used but working out is there...
        public bool SortingMemberMovieArray(Movie borrowed_movie)
        {
            if (Moviecount < 10)
            {
                MemberMovieCollection[Moviecount] = borrowed_movie;
                Moviecount++;

                //Increaments the borrow count
                borrowed_movie.Borrow();
                return true;
            }
            else
            {
                return false;
            }
        }

        //MEMBER MENU
        public void ListBorrowedMovies()
        {
            Console.WriteLine("You are currently borrwing: ");
            for (int i = 0; i < Moviecount; i++)
            {
                Console.WriteLine(MemberMovieCollection[i].Movie_Title);
            }

        }
    }

    public class MemberCollection
    {
        //Member Array which will store the member's new details in the array (this is the database)
        //Use an array as a class member to store the Members
        public Member[] MemberArray;

        public Member[] MemberMovieCollection;
  
        
        //No users instialised on start up
        int NumOfUsers;
        int Moviecount = 0;

        public MemberCollection()
        {
            //Constructing a Member
            Member Default = new Member();

            //10 Member
            MemberArray = new Member[] {Default, Default, Default, Default, Default, Default, Default, Default, Default, Default };

            //No Users intialised
            NumOfUsers = 0;
        }

        public bool AddUser(Member user)
        {
            if (NumOfUsers < 10)        //max amount of users
            {
                MemberArray[NumOfUsers++] = user;

                return true; //Member added
            }
            Console.WriteLine("10 users have already been registered in the system");
            Console.ReadLine();
            return false; //Member can't be added
        }

        //This is where username inputs go into (default array when main is started up)
        //public String [] default_memberarray = { "default", "", "", "", "", "", "", "", "", "" };
    }

    class Program
    {
        //Bool Checks
        static bool AddedMovie = false;
        static bool AddedMember = false;
        static bool ReturnedMemberNum = false;
        static bool Memberlogin = false;
        static bool FirstMemberLogin = false;
        static bool ReturnedPhoneNum = false;
        static bool ReturnedAllMovies = false;
        static bool MovieExist = false;
        static bool MovieDeleted = false;
        static bool MovieBorrowed = false;
        static bool ReturnedMovie = false;
        static bool DisplayedTop10 = false;


        static void MemberMenu()
        {
            Console.WriteLine("\n==========Member Menu==========");
            Console.WriteLine("1. Display all movies");
            Console.WriteLine("2. Borrow a movie DVD");
            Console.WriteLine("3. Return a movie DVD");
            Console.WriteLine("4. Display top 10 most popular movies");
            Console.WriteLine("0. Return to main menu");
            Console.WriteLine("==================================");
            Console.Write("Please make a selection (1-4 or 0 to return to main menu): ");
        }

        static void StaffMenu()
        {
            Console.WriteLine("\n==========Staff Menu===========");
            Console.WriteLine("1. Add a new movie DVD");
            Console.WriteLine("2. Remove a movie DVD");
            Console.WriteLine("3. Register a new Member");
            Console.WriteLine("4. Find a registered member's phone number");
            Console.WriteLine("0. Return to main menu");
            Console.WriteLine("=================================");
            Console.Write("Please make a selection (1-4 or 0 to return to main menu): ");
        }

        //Staff
        //IfExists Add Copies INstead
        static void AddNewMovie(MovieCollection CollectionOfMovies)
        {
            //UserInput to Console.Readline Vars
            string UserInput_MovieTitle;
            string UserInput_Starring;
            string UserInput_Director;
            int UserInput_Genre;
            int UserInput_Classifications;       //Change to int to Get from Movie Class String Array
            string UserInput_ReleaseDate;
            string UserInput_Duration;
            int UserInput_CopiesNumber;

            int UserInput_MovieCopies; //This has to be stored in the Tree somehow

            Console.Write("Enter the movie title: ");
            //Some Sort of console.Readline here to get movie title
            UserInput_MovieTitle = Console.ReadLine();

            //If Movie Exists Add copies instead
            foreach (Movie movie in CollectionOfMovies.MovieArray)
            {
                if (UserInput_MovieTitle == movie.Movie_Title)
                {
                    Console.Write("Enter the amount of copies you would like to add: ");
                    UserInput_CopiesNumber = int.Parse(Console.ReadLine());

                    //Logic here to assign it to intial_copies in Movie Object
                    movie.Movie_Copy_Num = UserInput_CopiesNumber;

                    Console.WriteLine("You added " + UserInput_CopiesNumber + " to " + UserInput_MovieTitle);

                    //Bool to Go back to main Menu
                    MovieExist = true;
                    break;
                }

                if (UserInput_MovieTitle != movie.Movie_Title)
                {
                    Console.Write("Enter the starring actor(s): ");
                    //Some Sort of console.Readline here to get actors
                    UserInput_Starring = Console.ReadLine();

                    Console.Write("Enter the director(s): ");
                    //Some sort of console.Readline to get directors
                    UserInput_Director = Console.ReadLine();

                    Console.WriteLine("\nSelect the genre:");
                    Console.WriteLine("1. Drama");
                    Console.WriteLine("2. Adventure");
                    Console.WriteLine("3. Family");
                    Console.WriteLine("4. Action");
                    Console.WriteLine("5. Sci-Fi");
                    Console.WriteLine("6. Comedy");
                    Console.WriteLine("7. Thirller");
                    Console.WriteLine("8. Other");
                    Console.Write("Make a selection(1-8): ");

                    //Get Genre type INT with console.Readline here      
                    UserInput_Genre = int.Parse(Console.ReadLine());

                    //Goes Through Classisfication Array
                    for (int i = 1; i < Movie.Genres.Length; i++)
                    {
                        {
                            if (UserInput_Genre.ToString() == Movie.Genres[i - 1]) //we are setting it at 1 because of menu options 
                            {
                                UserInput_Genre = i;
                            }
                        }
                    }

                    Console.WriteLine("\nSelect the classification: ");
                    Console.WriteLine("1. General (G)");
                    Console.WriteLine("2. Parental Guidance (PG)");
                    Console.WriteLine("3. Mature (M15+)");
                    Console.WriteLine("4. Mature Accompanied (MA15+)");
                    Console.Write("Make selection(1-4): ");
                    //Get Genre number (INT) here with console.Readline here
                    UserInput_Classifications = int.Parse(Console.ReadLine());

                    //Goes through Classisfications Array                                       //Doesn't get classifications (Doesn't Work)
                    for (int i = 1; i < Movie.Classisficiations.Length; i++)
                    {
                        {
                            if (UserInput_Classifications.ToString() == Movie.Classisficiations[i - 1]) //Since we are setting i at 1 because of menu options
                            {
                                UserInput_Classifications = i;
                            }
                        }
                    }

                    Console.Write("Enter the duration (minutes): ");
                    //Get duration minutes (INT) with conosle.Readline
                    UserInput_Duration = Console.ReadLine();

                    Console.Write("Enter the release date (year): ");
                    //Get four digit year (eg. 2019 INT) with console.Readline here
                    UserInput_ReleaseDate = Console.ReadLine();

                    Console.Write("Enter the number of copies available: ");
                    //Assigns copies avaiable value in here sets it BY STAFFF and Console.Readline() here (INT)
                    UserInput_MovieCopies = int.Parse(Console.ReadLine());

                    Movie StaffAddedMovie = new Movie(UserInput_MovieTitle, UserInput_Starring, UserInput_Director, UserInput_Duration, UserInput_Classifications, int.Parse(UserInput_ReleaseDate), UserInput_MovieCopies.ToString(), 0);    //Movie.Genres.ToString()[1]

                    //Add Movie to MovieCollection Array Here
                    CollectionOfMovies.AddMovie(StaffAddedMovie);
                    CollectionOfMovies = new MovieCollection();

                    //Need to add to MemberMovieCollection Here as well


                    //Return to staff Menu
                    AddedMovie = true;
                    break;
                }
            }
        }

        public static void DeleteMovie(MovieCollection CollectionOfMovies)
        {
            string UserInput_MovieTitle;

            Console.Write("Enter movie title: ");
            UserInput_MovieTitle = Console.ReadLine();


            foreach (Movie movie in CollectionOfMovies.MovieArray)
            {
                if (UserInput_MovieTitle == movie.Movie_Title)
                {
                    //Dummy Movie Object To Delete
                    Movie MovieToDelete = new Movie();

                    //Removes movie and re-creates the array again
                    CollectionOfMovies.RemoveMovie(MovieToDelete);
                    CollectionOfMovies = new MovieCollection();

                    Console.WriteLine(UserInput_MovieTitle + "" + " was deleted");

                    //Bool to Go back to main Menu
                    MovieDeleted = true;
                    break;
                }
                else if (UserInput_MovieTitle != movie.Movie_Title)
                {
                    Console.WriteLine("Movie does not exist");

                    //Bool to go back to main menu
                    MovieDeleted = true;
                    break;
                }

            }
        }

        public static void RegisterNewMember(MemberCollection CollectionOfMembers)
        {
            bool MemberInSystem = false;
            string FirstMemberName; //Need to assign these both somehow to the MemberCollection database
            string LastMemberName; //Need to assign these both somehow to the MemberCollection database
            string MemberAddress;
            int MemberPhoneNumber;
            int MemberPassword; //4 Digit Int

            int MemberCount = CollectionOfMembers.MemberArray.Length;

            Console.Write("Enter member's first name: ");
            FirstMemberName = Console.ReadLine();

            //Console.Readline assign to memberfirst name in MemberCollection

            Console.Write("Enter member's last name: ");
            LastMemberName = Console.ReadLine();

            foreach (Member member in CollectionOfMembers.MemberArray)
            {
                //If user is not in the system
                if (FirstMemberName + LastMemberName != member.Given_name + member.Surname)
                {
                    //Console.Readline assign to memberlast name in MemberCollection
                    Console.Write("Enter member's address: ");
                    MemberAddress = Console.ReadLine();

                    //Console.Readline assign to member's phone number in MemmberCollection
                    //This needs to also be assigned to Find a registered member's phone number
                    Console.Write("Enter member's phone number: ");
                    MemberPhoneNumber = int.Parse(Console.ReadLine());

                    Console.Write("Enter member's password(4 digits): ");
                    MemberPassword = int.Parse(Console.ReadLine());

                    Console.WriteLine("Sucessfully added " + FirstMemberName + " " + LastMemberName); //Need to assign to new Member First and Last name Paramaters in MemberCollection for this one

                    Member StaffAddedNewMember = new Member(FirstMemberName, LastMemberName, MemberAddress, MemberPhoneNumber, MemberPassword);

                    //Adding them to a new Array
                    CollectionOfMembers.AddUser(StaffAddedNewMember);
                    CollectionOfMembers = new MemberCollection();

                    //Bool to go back to case 3
                    AddedMember = true;
                    break;
                }

                //Wanna check the member is matched to a member.firstname (first time registeration) in the array
                //Do Compare to see if already registered with current Membercollection Database

                if (FirstMemberName + LastMemberName == member.Given_name + member.Surname)
                {
                    Console.WriteLine(FirstMemberName + " " + LastMemberName + " is already registered.");

                    //Bool check to go back to case 3 (Default menu)
                    AddedMember = true;
                    MemberInSystem = true;
                    break;
                }
            }
        }
        public static void GetPhoneNumber(MemberCollection CollectionOfMembers)     //Doesn't work, doesn't get new registered members in conosle
        {
            string FirstMemberName; //Need to assign these both somehow to the MemberCollection database
            string LastMemberName; //Need to assign these both somehow to the MemberCollection database

            Console.Write("Enter member's first name: ");
            FirstMemberName = Console.ReadLine();

            Console.Write("Enter member's last name: ");
            LastMemberName = Console.ReadLine();

            foreach (Member member in CollectionOfMembers.MemberArray)
            {
                //Wanna check the member is matched to a member.firstname (first time registeration) in the array
                //Do Compare to see if already registered with current Membercollection Database

                if (FirstMemberName + LastMemberName != member.Given_name + member.Surname)
                {
                    Console.WriteLine("Member does not exist");

                    //Bool Check goes here
                    ReturnedMemberNum = true;
                    break;
                }
                //Can't get each members name in the array 
                if (FirstMemberName + LastMemberName == member.Given_name + member.Surname) ;
                {
                    Console.WriteLine(FirstMemberName + " " + LastMemberName + " phone number is: " + member.PhoneNum);

                    //Bool to return to Staff Menu
                    ReturnedMemberNum = true;
                }
            } 
        }

        //-----------------------------------------------------------------------------------------------------------------
        static void StartMainMenu()
        {
            Console.WriteLine("\nWelcome to the Community Library");
            Console.WriteLine("============Main Menu=============");
            Console.WriteLine("1. Staff Login");
            Console.WriteLine("2. Member Login");
            Console.WriteLine("0. Exit");
            Console.WriteLine("==================================");
            Console.Write("Please make a selection (1-2 or 0 to exit): ");
        }

        //First Time logining in to the menu NOT REGISTERING
        static void MemberLogin(MemberCollection memberCollection)
        {
            String MemberUsername;
            String MemberPass;

            Console.Write("Enter your Username:(LastnameFirstname): ");
            MemberUsername = Console.ReadLine();

            Console.Write("Enter password: ");
            MemberPass = Console.ReadLine();

            //Compare these input vars to the MemberCollection database (WHICH HOLDS THE REGISTERED USERS IN THERE) 
            foreach (Member item in memberCollection.MemberArray)
            {
                if (MemberUsername == item.Surname + item.Given_name && MemberPass == item.Password.ToString())
                {
                    //Bool Check to go to MemberMenu
                    Memberlogin = true;

                    //Another check for the switch case only
                    FirstMemberLogin = true;
                }        
            }
            if (Memberlogin == false)
            {
                Console.WriteLine("Incorrect Login");
            }
        }

        static bool MoviesToExclude()
        {
            return false;
        }

        //Member
        static void DisplayAllMovie(MovieCollection moviecollection)
        {
            foreach (Movie movie in moviecollection.MovieArray)       /// Maybe use MovieCOunt???
            {
                //Trying to Exclude Movie but not sure how to 
                /*
                if (moviecollection.MovieArray[i].Movie_Title == "TestMovie")
                {
                
                }
                */

                //Calling each movies Properties 
                Console.WriteLine("\nTitle: " + movie.Movie_Title);
                Console.WriteLine("Starring: " + movie.Movie_Starring);
                Console.WriteLine("Director: " + movie.Movie_Director);
                Console.WriteLine("Duration: " + movie.Movie_Duration);
                Console.WriteLine("Genre: " + movie.Movie_Genre);
                Console.WriteLine("Classification: " + movie.Movie_Classificaiton);
                Console.WriteLine("Release Date: " + movie.Movie_Release_Date);
                Console.WriteLine("Copies Available: " + movie.Movie_Copy_Num);
                Console.WriteLine("Times Borrowed: " + movie.Movie_Times_Borrowed);
            }
            //Return Back to Menu
            ReturnedAllMovies = true;
        }
        //Member
        static void BorrowAMovie(MovieCollection CollectionOfMovies)
        {
            Console.WriteLine("Enter a movie Title: ");
            string Movietitle = Console.ReadLine();
            
            foreach (Movie movieitem in CollectionOfMovies.MovieArray)
            {
                //Doesn't exists
                if (Movietitle != movieitem.title)
                {
                    //Doesn't Exists
                    Console.WriteLine("Movie doesn't exists ");

                    //Returns back to main menu
                    MovieBorrowed = true;
                    break;
                }

                //Exists
                if (Movietitle == movieitem.title)
                {
                    Console.WriteLine(Movietitle + " was borrowed");

                    //Actually add to the MoviememberCollection + decrease copies and increase time borrowed
                    //.......

                    //Returns back to main menu
                    MovieBorrowed = true;
                    break;
                }
            }
        }

        //Member
        static void ReturnAMovie(MovieCollection CollectionOfMovies)
        {
            Console.WriteLine("Enter a movie Title: ");
            string Movietitle = Console.ReadLine();

            foreach (Movie movieitem in CollectionOfMovies.MovieArray)
            {
                //Doesn't exists
                if (Movietitle != movieitem.title)
                {
                    //Doesn't Exists
                    Console.WriteLine("Movie doesn't exists ");

                    //Returns back to main menu
                    ReturnedMovie = true;
                    break;
                }

                //Exists
                if (Movietitle == movieitem.title)
                {
                    Console.WriteLine(Movietitle + " was deleted");

                    //Actually add to the MoviememberCollection + increase 
                    //.......

                    //Returns back to main menu
                    MovieDeleted = true;
                    break;
                }
            }
        }
        
        //MEMBER
        static void DisplayTop10Movies()
        {
            //Put Algorithm here (based off the pesudocode from lec 5 CAB301)
            
            //Would display all movies in decreasing order from timesborrowed
            Console.WriteLine("This function doesn't work");

            //Goes back to main menu
            DisplayedTop10 = true;
        }

        //Function that sorts via mergesort pesudocode from lecture

        //Calulates the midpoint of the array (Q) and then Merges, creating 2 subarrays and afterwards goes into the Merge function
        static public void MergeSort(int[] ArrayToSort, int p, int r)
        {
            if (p < r)
            {
                int q = (p + r) / 2;
                MergeSort(ArrayToSort, p, q);
                MergeSort(ArrayToSort, q + 1, r);
                Merge(ArrayToSort, p, q, r);
            }
        }

        //Merge it is given two subarrays from MergeSort and this function merges these subarrrays into a 1
        static public void Merge(int[] ArrayToSort, int p, int q, int r)
        {
            int i, j, k;
            int n1 = q - p + 1;
            int n2 = r - q;
            int[] L = new int[n1];
            int[] R = new int[n2];

            for (i = 0; i < n1; i++)
            {
                L[i] = ArrayToSort[p + i];
            }

            for (j = 0; j < n2; j++)
            {
                R[j] = ArrayToSort[q + 1 + j];
            }

            i = 0;
            j = 0;
            k = p;

            while (i < n1 && j < n2)
            {
                if (L[i] <= R[j])
                {
                    ArrayToSort[k] = L[i];
                    i++;
                }
                else
                {
                    ArrayToSort[k] = R[j];
                    j++;
                }
                k++;
            }

            while (i < n1)
            {
                ArrayToSort[k] = L[i];
                i++;
                k++;
            }

            while (j < n2)
            {
                ArrayToSort[k] = R[j];
                j++;
                k++;
            }
        }

        //-------------------------------------------------------------------------------------------
        static void Exit()
        {
            Environment.Exit(0);
        }

        ///The (.EXE File)
        public static void Main(string[] args)
        {
            #region //BTS TREE STUFF
            /*	// build a binary search tree
                IBSTree aBSTree = new BSTree();
                aBSTree.Insert('M');
                aBSTree.Insert('D');
                aBSTree.Insert('G');
                aBSTree.Insert('A');
                aBSTree.Insert('W');
                aBSTree.Insert('P');

                // pre-order traversal
                aBSTree.PreOrderTraverse();
                // in-order traversal
                aBSTree.InOrderTraverse();
                // post-order traversal
                aBSTree.PostOrderTraverse();

                // delete a leaf A
                aBSTree.Delete('A');

                // pre-order traversal
                aBSTree.PreOrderTraverse();
                // in-order traversal
                aBSTree.InOrderTraverse();
                // post-order traversal
                aBSTree.PostOrderTraverse();

                // put A back aBStree
                aBSTree.Insert('A');
                // delete a node W, which has only one child
                aBSTree.Delete('W');

                // pre-order traversal
                aBSTree.PreOrderTraverse();
                // in-order traversal
                aBSTree.InOrderTraverse();
                // post-order traversal
                aBSTree.PostOrderTraverse();

                // clear the binary tree
                aBSTree.Clear();

                // pre-order traversal
                aBSTree.PreOrderTraverse();
                */
            #endregion

            //-------------------------------------------------------------------------
            //Self Deciding Switch Case Below (EXE BASICALLY VOID START w/ UPDATE));

            //Declaring Vars
            //Setting Userinput to 0 (default)

            int userinput = 0;
            int FirstUserInput = -1;

            //Initalises Array (adding it to an a array)
            MemberCollection CollectionOfMembers;
            MovieCollection CollectionOfMovies;

            //Initialising Collection of Members as new Membercollection Constructor
            //Calling Constructor above in MemberCollection
            CollectionOfMembers = new MemberCollection();

            //Initialising Collection of Movies as new Moviecollection Constructor
            //Calling Constructor above in MovieCollection
            CollectionOfMovies = new MovieCollection();

            //Hardcoded member in main FOR TESTING ONLY (Since members don't add to the array for some reason) / Now MemberLogin/Functions work
            Member MemberTestObj = new Member("Bob", "Smith", "Sydeny", 1111, 2222);
            Member MemberTestObj2 = new Member("Bob1", "Smith1", "Sydeny", 2222, 2222);
            Member MemberTestObj3 = new Member("Bob2", "Smith2", "Sydeny", 3333, 2222);
            Member MemberTestObj4 = new Member("Bob3", "Smith3", "Sydeny", 4444, 2222);
            //Adds Object to Array
            CollectionOfMembers.AddUser(MemberTestObj);
            CollectionOfMembers.AddUser(MemberTestObj2);
            CollectionOfMembers.AddUser(MemberTestObj3);
            CollectionOfMembers.AddUser(MemberTestObj4);

            //Testing for DISPLAYALL FUNCTION---------------------------------------------------------------
            //Hardcoded member in main FOR TESTING ONLY
            Movie MovieTestObj = new Movie("Movie1", "Actor1, Actor2, Actor3", "Director", "90", Movie.Genres.ToString()[1], 0 ,"" ,0 );
            
            //Adds Object to Array
            CollectionOfMovies.AddMovie(MovieTestObj);

            //Starting up EXE with Openning Menu
            StartMainMenu();
            FirstUserInput = int.Parse(Console.ReadLine());

            if (FirstUserInput == 1) //STAFF LOGIN
            {
                //StaffLogin();
                string StaffUser = "staff";
                string StaffPass = "today123";

                Console.Write("Enter username: ");

                //GetUserName
                string GetUsername = Console.ReadLine();
                Console.Write("Enter Password: ");

                //Get Password Here
                string GetPass = Console.ReadLine();

                if (GetUsername == StaffUser && GetPass == StaffPass)
                {
                    //Goes into Switch Case 1
                    userinput = 1;
                }
                if (GetUsername != StaffUser || GetPass != StaffPass )   //If incorrect terminate program
                {
                    Console.WriteLine("Login incorrect, goodbye!");
                    Console.ReadLine();
                }
            }
            if (FirstUserInput == 2) //Member LOGIN
            {
                MemberLogin(CollectionOfMembers);

                //Bool Check
                if (Memberlogin == true)
                {
                    Memberlogin = false;
                    //Goes to MemberCase Switch Case 2
                    userinput = 2;

                } 
            }
            if (FirstUserInput == 0) //If user presses 0 EXITS
            {
                    Exit(); 
            }

            switch (userinput) //STAFF MENU
            {
                case 1:
                    //Resetting the UserInput
                    FirstUserInput = -1;
                    StaffMenu();
                   
                    FirstUserInput = int.Parse(Console.ReadLine());

                    //Add new movie DVD
                    if (FirstUserInput == 1)
                    {
                        userinput = 1;
                        AddNewMovie(CollectionOfMovies);

                        //If Movie exist go back to case1
                        if(MovieExist == true)
                        {
                            MovieExist = false;

                            userinput = 1;
                            goto case 1;
                        }
                        
                        //If at end of AddMovie goto Case 1 (bool AddedMovie = true)
                        if (AddedMovie == true)
                        {
                            AddedMovie = false;

                            userinput = 1; //Goes to StartMainMenu
                            goto case 1; //Should be back to Staff Main Menu
                        }
                    }

                    //Remove a Movie DVD
                    if (FirstUserInput == 2)
                    {
                        DeleteMovie(CollectionOfMovies);

                        //To Go back to Main Menu
                        if (MovieDeleted == true)
                        {
                            MovieDeleted = true;
                            goto case 2;
                        }

                    }

                    //Register a new Member
                    if (FirstUserInput == 3)
                    {
                        RegisterNewMember(CollectionOfMembers);

                        if (AddedMember == true)
                        {
                            //Back to staff main menu
                            goto case 1;
                        }
                    }

                    //Find a register member's phone number
                    if (FirstUserInput == 4)
                    {
                        GetPhoneNumber(CollectionOfMembers);

                        if (ReturnedMemberNum == true)
                        {
                            //Reset the bool
                            ReturnedMemberNum = false;
                            //Back to staff main menu
                            goto case 1;
                        }
                    }

                    //0 = Go Back TO STARTMENU
                    //Return To StartMenu from StaffMenu
                    if (FirstUserInput == 0)
                    {
                        goto case 3;
                    }
                    break;

                case 2: 
                    //MemberLogin Menu
                    userinput = 2;  //For Switch Statement
                    FirstUserInput = -1;

                    MemberMenu();

                    FirstUserInput = int.Parse(Console.ReadLine());
                    
                    //Display all moives
                    if (FirstUserInput == 1)
                    {
                        DisplayAllMovie(CollectionOfMovies);
                        
                        //Bool Check to Return
                        if (ReturnedAllMovies == true)
                        {
                            //Resetting Bool
                            ReturnedAllMovies = false;
                            goto case 2;
                        }
                    }

                    //Borrow a moive
                    if (FirstUserInput == 2)
                    {
                        //Doesn't actually borrow to MovieMemberCollection but better then nothing
                        BorrowAMovie(CollectionOfMovies);
                        
                        //Other Borrow functions above as well for reference just can't figure out how to use them (In Member Class)

                        //Bool Check to Return;
                        if (MovieBorrowed == true)
                        {
                            MovieBorrowed = false;
                            goto case 2;
                        }
                    }

                    //Return a movie DVD
                    if (FirstUserInput == 3)
                    {
                        //Doesn't actually return to MovieMemberCollection but better then nothing
                        ReturnAMovie(CollectionOfMovies);

                        //Bool Check to Return;
                        if (ReturnedMovie == true)
                        {
                            ReturnedMovie = false;
                            goto case 2;
                        }
                    }

                    //List current borrowed movie DVDS
                    if (FirstUserInput == 4)
                    {
                        //Have written logic below in that function up in members but have not got it working
                        //ListBorrowedMovies();

                        Console.WriteLine("This function doesn't work");
                        Console.ReadLine();

                        //Return to menu
                        goto case 2;
                    }

                    //Display top 10 most popular movies (Alogothrim THAT NEEDS TO BE MADE)
                    if (FirstUserInput == 5)
                    {
                        //Have written an algothrim doesn't work with tree or MovieCollection
                        DisplayTop10Movies();

                        if (DisplayedTop10 = true)
                        {
                            DisplayedTop10 = false;
                            //Return to menu
                            goto case 2;
                        }
                    }

                    //Return to Main Menu 
                    if (FirstUserInput == 0)
                    {
                        goto case 3;
                    }
                    break;

                case 3:
                    FirstUserInput = -1;

                    //BACK TO START MENU CASE
                    StartMainMenu();
                    FirstUserInput = int.Parse(Console.ReadLine());

                    if (FirstUserInput == 1) //STAFF LOGIN
                    {
                        //StaffLogin();
                        string StaffUser = "staff";
                        string StaffPass = "today123";

                        Console.Write("Enter username: ");
                        //GetUserName
                        string GetUsername = Console.ReadLine();
                        Console.Write("Enter Password: ");
                        //Get Password Here
                        string GetPass = Console.ReadLine();

                        if (GetUsername == StaffUser && GetPass == StaffPass)
                        {
                            //Goes into swtich
                            userinput = 1;
                            goto case 1;
                        }
                        if (GetUsername != StaffUser || GetPass != StaffPass)
                        {
                            Console.WriteLine("Login incorrect, goodbye!");
                            Console.ReadLine();
                        }
                    }
                    else if (FirstUserInput == 2) //Member LOGIN
                    {
                        MemberLogin(CollectionOfMembers);

                        //Bool Check
                        if (Memberlogin == true)
                        {
                            Memberlogin = false;
                            //Goes to MemberCase Switch Case 2
                            userinput = 2;
                            goto case 2;
                        }
                    }
                    else if (FirstUserInput == 0) //If user presses 0 EXITS
                    {
                        Exit();
                    }
                    else
                    {
                        Console.WriteLine("Invalid Selection, Goodbye");
                    }
                    break;
            }
        }
    }
}
